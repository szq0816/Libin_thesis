%%%%%%%%%%----RDDMF----%%%%%%%%%
clc
clear
addpath(genpath('.'));
warning off;
bounds = 1;
load E:\R2020a\bin\datasets\Handwritten.mat; %%NH_interval9_mtv
%%
savePath = './result/yale/';
% Yale Dataset -----------------------------
% load ./datasets/Handwritten.mat;
% for dd = 1:4
% if dd>1
% clear;
% end
% X{1} = mfeat_fac';
% X{2} = mfeat_fou';
% X{3} = mfeat_kar';
% gt = truth;
for ib = 1:bounds
%    if dd == 1
       layers = [100 50] ;
       fea = X;
       gnd = gt;
       ind = numel(X);
       for ix = 1:ind
            X{1,ix} = NormalizeFea(X{1,ix}, 0);
       end
       graph_k = 5;
       gamma = 0.5;
       beta = 0;%%%对应模型中的参数lammda
       lamda = 0.01;%%%对应模型中的参数beta
       miu = 1;
       [ ACC1,NMI1,AR1,F1,P1,R1] = RDDMF( fea, layers, 'gnd', gnd,...
            'gamma', gamma, 'beta', beta,'lamda',lamda, 'miu', miu , 'graph_k', graph_k, 'savePath', savePath);
        ACC(ib) = ACC1;
        NMI(ib) = NMI1;
        AR(ib) = AR1;
        F(ib) = F1;
        P(ib) = P1;
        R(ib) = R1;
end
mACC = mean(ACC);
sACC = std(ACC);
mNMI = mean(NMI);
sNMI = std(NMI);
mAR = mean(AR);
sAR = std(AR);
mF = mean(F);
sF = std(F);
mP = mean(P);
sP = std(P);
mR = mean(R);
sR = std(R);
fprintf(1, 'ACC is %.4f, sACC is %.4f\n, NMI is %.4f\n,sNMI is %.4f\n,AR is %.4f\n,sAR is %.4f\n', mACC, sACC,mNMI,sNMI,mAR,sAR);
fprintf(1, 'F is %.4f, sF is %.4f\n, P is %.4f\n,sP is %.4f\n,R is %.4f\n,sR is %.4f\n', mF, sF,mP,sP,mR,sR);
%       dd
%    end
%    if dd ==2
%         load('yaleB_mtv.mat');
%         layers = [100 50] ;
%         fea = X;
%         gnd = gt;
%         ind = numel(X);
%         for ix = 1:ind
%             X{1,ix} = NormalizeFea(X{1,ix}, 0);
%         end
%         graph_k = 5;
%         gamma = 0.5;
%         beta = 0.01;
%         lamda = 0.01;
%         miu = 0.01;%%%0.01/0.001
%         [ Z1, H1, dnorm1 ] = deepMF_multiview3( fea, layers, 'gnd', gnd,...
%             'gamma', gamma, 'beta', beta,'lamda',lamda, 'miu', miu, 'graph_k', graph_k, 'savePath', savePath);
%         dd
%    end
%    if dd ==3
%         load('NH_interval9_mtv.mat');
%         layers = [100 50] ;
%         fea = X;
%         gnd = gt;
%         for ix = 1:ind
%             X{1,ix} = NormalizeFea(X{1,ix}, 0);
%         end
%         graph_k = 50;
%         gamma = 0.5;
%         beta = 0.01;
%         lamda = 0.01;
%         miu = 1e-2;%%%0.01/0.001
%         [ Z1, H1, dnorm2 ] = deepMF_multiview3( fea, layers, 'gnd', gnd,...
%             'gamma', gamma, 'beta', beta,'lamda',lamda, 'miu', miu,'dd',dd, 'graph_k', graph_k, 'savePath', savePath);
%         dd
%    end
%    if dd==4
%       load('COIL20MV.mat');
%       ind = numel(X);
%       for ix = 1:ind
%           X{1,ix} = NormalizeFea(X{1,ix}, 0);
%       end
%       layers = [100 50] ;
%       graph_k = 150;
%       gamma = 0.5;
%       beta = 0.01;
%       lamda = 0.001;
%       miu = 1e-2;%%%0.01/0.001
%       [ Z1, H1, dnorm3 ] = deepMF_multiview3( fea, layers, 'gnd', gnd,...
%             'gamma', gamma, 'beta', beta,'lamda',lamda, 'miu', miu,'dd',dd, 'graph_k', graph_k, 'savePath', savePath);
%       dd
%    end
            
% end

%%

%%yale:[100 60],5,05/5,0.01,0.01,0.001/0.022
%%yaleB:[200 50], 5, 0.01, 0.1, 0.1,0.22
%%NH:[300 100],105,,5,0.01,0.01/[120 45],105,5,0.01,0.01,0.1
%%[250 50] 16 5 0.01 0.01 0.01
%%HW:[100 50],50,0.5,0.01,0.01,1