function [fea, gnd] = select_class(k, fea, gnd)
    nClass = length(unique(gnd));
    a = randperm(nClass);
    a = a(1:k);
    b = [];
    for i = 1:k
        temp = find(gnd == a(i));
        b = [b; temp];
        clear temp;
    end
    fea = fea(b, :);
    gnd = gnd(b);
    a = unique(gnd);
    b = length(a);
    for i = 1:b
        idx = gnd==a(i);
        gnd(idx) = i;
    end
end
