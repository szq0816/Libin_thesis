function [ Z, H, dnorm1 ] = semi_deepMF( XX, layers, varargin )
% contain all the stuffs,
% including graph and beta between lost and graph term

% Process optional arguments
pnames = { ...
    'z0' 'h0' 'bUpdateH' 'bUpdateLastH' 'maxiter' 'TolFun', ...
    'verbose', 'bUpdateZ', 'cache', 'gnd', 'gamma', 'beta','lamda', 'miu', 'graph_k', 'savePath'...
    };

% each view should be initialized also.
numOfView = numel(XX);
num_of_layers = numel(layers);
numOfSample = size(XX{1,1},2);

alpha = ones(numOfView,1).*(1/numOfView);  %��ʼ��alpha
dflts  = {0, 0, 1, 1, 250, 1e-5, 1, 1, 0, 0};
[z0, h0, bUpdateH, bUpdateLastH, maxiter, tolfun, verbose, bUpdateZ, cache, gnd, gamma, beta,lamda, miu, graph_k,savePath] = ...
    internal.stats.parseArgs(pnames,dflts,varargin{:});

c = 5;
per = 0.01;
options = [];
options.k = graph_k;
options.WeightMode = 'HeatKernel';
options.t = 1e0;
% C1 = eye(165,150);
for v_ind = 1:numOfView
    X = XX{v_ind};
    X = bsxfun(@rdivide,X,sqrt(sum(X.^2,1)));
%     [selectX, selectG] = select_class(c, X', gnd);
%     Wz{v_ind} = constructW(X,options);
%     Wh{v_ind} = constructW(X',options);
%     Dz{v_ind} =diag(sum(Wz{v_ind}));
%     Dh{v_ind} =diag(sum(Wh{v_ind}));
    [~, ~, ~, C{v_ind}, ~] = Select_label(X', double(gnd), c, per);
%     Lz_graph{v_ind} = Dz{v_ind} - Wz{v_ind};  
%     Lh_graph{v_ind} = Dh{v_ind} - Wh{v_ind};
%     C{v_ind} = C1;
    if  ~iscell(h0)
        for i_layer = 1:length(layers)
            if i_layer == 1
                % For the first layer we go linear from X to Z*H, so we use id
                V = X;
            else
                V = H{v_ind,i_layer-1};
            end

            if verbose
                display(sprintf('Initialising Layer #%d with k=%d with size(V)=%s...', i_layer, layers(i_layer), mat2str(size(V))));
            end
            
            [~,c1]=size(C{v_ind});
            Al{v_ind,i_layer} = rand(c1,layers(i_layer));
            if ~iscell(z0)
                % For the later layers we use nonlinearities as we go from
                % g(H_{k-1}) to Z*H_k
                [Z{v_ind,i_layer}, H{v_ind,i_layer}, ~] = ...
                    seminmf(V, ...
                    layers(i_layer), ...
                    'maxiter', maxiter, ...
                    'bUpdateH', true, 'bUpdateZ', bUpdateZ, 'verbose', verbose, 'save', cache, 'fast', 1);
%                 Al{v_ind,i_layer} = (H{v_ind,i_layer}*pinv(C{v_ind}'))';
                Al{v_ind,i_layer} = pinv(C{v_ind})*H{v_ind,i_layer}';
            else
                display('Using existing Z');
                [Z{v_ind,i_layer}, H{v_ind,i_layer}, ~] = ...
                    seminmf(V, ...
                    layers(i_layer), ...
                    'maxiter', 1, ...
                    'bUpdateH', true, 'bUpdateZ', 0, 'z0', z0{i_layer}, 'verbose', verbose, 'save', cache, 'fast', 1);
%                 Al{v_ind,i_layer} = (H{v_ind,i_layer}*pinv(C{v_ind}'))';
                Al{v_ind,i_layer} = pinv(C{v_ind})*H{v_ind,i_layer}';
            end
        end
        
    else
        Z=z0;
        H=h0;
        if verbose
            display('Skipping initialization, using provided init matrices...');
        end
    end
%     dnorm0(v_ind) = cost_function_graph1(X, Z1(v_ind,:), H1(v_ind,:), alpha1(v_ind)^gamma, Lh_graph{v_ind}, Lz_graph{v_ind}, beta, miu,Pi);
%     dnorm(v_ind) = dnorm0(v_ind) + 1;
    if verbose
%         display(sprintf('#%d error: %f', 0, sum(dnorm0)));
    end
end

for v_ind = 1:numOfView
    for i = 1:numel(layers)
        H{v_ind,i} = Al{v_ind,i}'*C{v_ind}';
        X1 = Z{v_ind,i}*H{v_ind,i};
        Ah{v_ind,i} = constructW(X1', options);
        Dh{v_ind,i} = diag(sum(constructW(X1', options),2));
        Lh{v_ind,i} = Dh{v_ind,i} - Ah{v_ind,i};
    
        Az{v_ind,i} = constructW(X1, options);
        Dz{v_ind,i} = diag(sum(constructW(X1, options),2));
        Lz{v_ind,i} = Dz{v_ind,i} - Az{v_ind,i};
    end
end
%% Error Propagation

if verbose
    display('Finetuning...');
end
H_err = cell(numOfView, num_of_layers);
A_err = cell(numOfView, num_of_layers);
D = cell(numOfView, num_of_layers);

for iter = 1:maxiter
    for v_ind = 1:numOfView
        X = XX{v_ind};
        X = bsxfun(@rdivide,X,sqrt(sum(X.^2,1)));
        H_err{v_ind,numel(layers)} = H{v_ind,numel(layers)};
        A_err{v_ind,numel(layers)} = Al{v_ind,numel(layers)};
        for i_layer = numel(layers)-1:-1:1
            H_err{v_ind,i_layer} = Z{v_ind,i_layer+1} * H_err{v_ind,i_layer+1};
%             A_err{v_ind,i_layer} = (H_err{v_ind,i_layer}*pinv(C{v_ind}'))';
            A_err{v_ind,i_layer} = pinv(C{v_ind})*H_err{v_ind,i_layer}';
        end

        for i = 1:numel(layers)
            if bUpdateZ
                try
                    if i == 1
                      D{v_ind,i} = Z{v_ind,1};
                    else
                      D{v_ind,i} = D{v_ind,i-1}*Z{v_ind,i};  %%??i-1??
                    end

%                      [m,n] = size(Z{v_ind,i});
%                      Q = eye(m);
                if i == 1
                   Za{v_ind,i} = X  *C{V_ind}* A_err{v_ind,i}+lamda*(Az{v_ind}*Z{v_ind,i});
                   Zb{v_ind,i} = Z{v_ind,i}*(A_err{v_ind,i})'*(C{v_ind})'*C{v_ind}*A_err{v_ind,i}+lamda*(Dz{v_ind}*Z{v_ind,i});
                   Z{v_ind,i} = Z{v_ind,i}.*(Za{v_ind,i}./Zb{v_ind,i});
                else
                   Za{v_ind,i} = D' * X*C{V_ind}* A_err{v_ind,i}+lamda*(Az{v_ind}*Z{v_ind,i});
                   Za{v_ind,i} = D' * D*Z{v_ind,i}*(A_err{v_ind,i})'*(C{v_ind})'*C{v_ind}*A_err{v_ind,i}+lamda*(Dz{v_ind}*Z{v_ind,i});
                   Z{v_ind,i} = Z{v_ind,i}.*(Za{v_ind,i}./Zb{v_ind,i});
                end
%                 Pi = sqrt(sum(Z{v_ind,i}.*Z{v_ind,i},2) + eps);
%                 d = 0.25./(Pi.^3/2);
%                 Q = diag(d);

                catch
%                     display(sprintf('Convergance error %f. min Z{i}: %f. max %f', norm(Z{v_ind,i}, 'fro'), min(min(Z{v_ind,i})), max(max(Z{v_ind,i}))));
                end
            end
            A = D{v_ind,i}' * X;
            Ap = (abs(A)+A)./2; 
            An = (abs(A)-A)./2;    
            B = D{v_ind,i}' * D{v_ind,i};
            Bp = (abs(B)+B)./2;  
            Bn = (abs(B)-B)./2;                     

%             HQ = miu*Q*A_err{v_ind,i};
%             HQp = (abs(HQ)+HQ)./2;
%             HQn = (abs(HQ)-HQ)./2;
            E = X'*D{v_ind,i};
            Ep = (abs(E)+E)./2;
            En = (abs(E)-E)./2;
            
            if bUpdateH && (i < numel(layers) || (i == numel(layers) && bUpdateLastH))
                Aia{v_ind,i} = C{v_ind}'*Ep+C{v_ind}'*C{v_ind}*A_err{v_ind,i}*Bn+beta*C{v_ind}'*Ah{v_ind}*C{v_ind}*Al{v_ind,i}; 
                Aib{v_ind,i} = max(C{v_ind}'*En+C{v_ind}'*C{v_ind}*A_err{v_ind,i}*Bp+beta*C{v_ind}'*Dh{v_ind}*C{v_ind}*Al{v_ind,i}, 1e-10);
                Al{v_ind,i} = Al{v_ind,i} .* (Aia{v_ind,i}./Aib{v_ind,i});
            end
        end      
        assert(i == numel(layers));
    end
   
    for v_ind = 1:numOfView
        
        X = XX{v_ind};
        X = bsxfun(@rdivide,X,sqrt(sum(X.^2,1)));
        
        % update Hm
%         H{v_ind,num_of_layers} = H{v_ind,num_of_layers} .* sqrt(Hm_a ./ Hm_b);
        
        % get the error for each view
        dnorm(v_ind) = cost_function_graph(X, Z(v_ind,:), Al(v_ind,:),C{v_ind}, alpha(v_ind)^gamma, Lh(v_ind,:),Lz(v_ind,:), beta,lamda);
        
        % the following two lines are used for calculating weight
        tmpNorm = cost_function_graph(X, Z(v_ind,:), Al(v_ind,:), C{v_ind},1, Lh(v_ind,:),Lz(v_ind,:), beta,lamda);
        dnorm_w(v_ind) = (gamma*(tmpNorm))^(1/(1-gamma));
    end
    
     %update alpha
    for v_ind = 1:numOfView
        alpha(v_ind) = dnorm_w(v_ind)/sum(dnorm_w);
    end
% 
%     % finish update Z H and other variables in each view
%     % disp result
%     maxDnorm1 = sum(dnorm1);
    if verbose
%         display(sprintf('#%d error: %f', iter, maxDnorm1));
        display(sprintf('#%d', iter));
    end
    
    if verbose && length(gnd) > 1
        if mod(iter, 1) == 0|| iter ==1
            [acc, nmii, AR, F, P, R,~]= evalResults_multiview1(Al{numOfView,num_of_layers},C{numOfView}, gnd);
            ac = mean(acc);
            nmi = mean(nmii);
            AR = mean(AR);
            F = mean(F);
            P = mean(P);
            R = mean(R);
            fprintf(1, 'Clustering accuracy is %.4f, NMI is %.4f\n', ac, nmi);
            disp(sprintf('AR: %0.4f\tF:%4f\tP:%4f\tR:%4f\t', AR, F, P, R));
        end
    end
%     dnorm0 = maxDnorm1;
    
end

end

function error = cost_function(X, Z, H, weight)
error = weight*norm(X - reconstruction(Z, H), 'fro');
end

function error = cost_function_graph(X, Z, Al,C, weight, LH,LZ, beta,lamda)
a = numel(Al);
obj1 = 0;
obj2 = 0;
for i = 1:a
    H{i} = Al{i}'*C';
    out = H{i};
    out1 = Z{i};
    Ao = LH{i};
    Ao1 = LZ{i};
    obj1 = beta* trace(out*Ao*out')+obj1;
    obj2 = lamda* trace(out1'*Ao1*out1)+obj2;
end

error = weight*(norm(X - reconstruction(Z, H), 'fro') + obj1+ obj2);
end

function [ out ] = reconstruction( Z, H )

out = H{numel(H)};

for k = numel(H) : -1 : 1
    out =  Z{k} * out;
end

end
